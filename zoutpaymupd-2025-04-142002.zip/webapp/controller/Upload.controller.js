sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
], function (Controller, JSONModel, MessageToast) {
    "use strict";
    return Controller.extend("zoutpaymupd.controller.Upload", {
        onInit() {
            this.oTableModel = new JSONModel();
            this.getView()?.setModel(this.oTableModel, 'TableDataModel');
            this.oTableModel.setProperty("/List", [])
        },
        update(data) {
            let oldData = this.oTableModel.getProperty("/List");
            let newData = [...data, ...oldData];
            this.oTableModel.setProperty("/List", newData);
        },
        onUpload(oEvent) {
            var that = this;
            var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
            if (!file) {
                console.error("No file selected.");
                return;
            }
            if (window.FileReader) {
                var reader = new FileReader();
                reader.onloadstart = function () {
                    console.log("File reading started...");
                };
                reader.onload = function (e) {
                    var data = e.target.result;
                    try {
                        var workbook = XLSX.read(data, {
                            type: 'binary'
                        });
                        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
                            console.error("No sheets found in the Excel file.");
                            return;
                        }
                        var excelData = [];
                        var headers = [];
                        let datas = [];
                        workbook.SheetNames.forEach(function (sheetName) {
                            var worksheet = workbook.Sheets[sheetName];
                            excelData = XLSX.utils.sheet_to_row_object_array(worksheet);
                            headers = XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0];
                            excelData.forEach((element) => {
                                datas.push({
                                    Companycode: element["Company Code"],
                                    Documentdate: element["Document Date"],
                                    Currencycode: element["Currency Code"],
                                    Bpartner: element["Supplier"],
                                    Glamount: element["Amount"],
                                    Businessplace: element["Business Place"],
                                    Sectioncode: element["Section Code"],
                                    Gltext: element["Text"],
                                    Glaccount: element["G/L Account"],
                                    Housebank: element["House Bank"],
                                    Accountid: element["Account Id"],
                                    Profitcenter: element["Profit Center"],
                                });
                            });
                            that.update(datas);

                        });

                    } catch (error) {
                        console.error("Error parsing the Excel file: ", error);
                    }
                };
                reader.onerror = function (error) {
                    console.error("Error reading file: ", error);
                };
                reader.readAsBinaryString(file);
            } else {
                console.error("FileReader is not supported in this browser.");
            }
        },
        handleUpload() {
            let data = this.oTableModel.getProperty("/List"),
            that = this;
            let selectedIndex = this.byId("MainList").getSelectedIndices();
            let addedindex = []
            if (!selectedIndex.length) {
                MessageToast.show("No data Selected");
                return
            };

            let newdata = data.map((item,index)=>{
                if(!selectedIndex.includes(index)) return null;
                addedindex.push(index)
                const [day, month, year] = item.Documentdate.split("-");
                const formattedDate = `${year}${month}${day}`;
                return {
                    ...item,
                    Accountid:item.Accountid.toString(),
                    Documentdate:formattedDate,
                    Bpartner:item.Bpartner.toString(),
                    Glaccount:item.Glaccount.toString()
                }
            }).filter(item=>item !== null );

            $.ajax({
                url: '/sap/bc/http/sap/ZHTTP_OUTGOINGPAYM',
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify(newdata),
                success: function (response) {
                    MessageToast.show(response);
                    data = data.filter((item,index)=>!addedindex.includes(index))
                    that.oTableModel.setProperty("/List",data);
                },
                error: function (error) {
                    MessageToast.show("Upload failed: " + (error.responseText || "Unknown error"));
                }
            });

        }
    });
});
