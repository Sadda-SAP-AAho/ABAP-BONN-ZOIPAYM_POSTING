import Controller from "sap/ui/core/mvc/Controller";
import ODataModel from "sap/ui/model/odata/v2/ODataModel";
import Table from "sap/m/Table";
import SmartTable from "sap/ui/comp/smarttable/SmartTable";

/**
 * @namespace zpendoipaym.controller
 */
export default class Grid extends Controller {

    public oDataModel: ODataModel;
    public selectedDoc: string;

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {
        this.oDataModel = new ODataModel("/sap/opu/odata/sap/ZUI_OIPAYMENTS_O2/", {
            defaultCountMode: "None"
        });
    }

    public onClickDelete() {
        let selectedData = (this.byId("RespTable") as Table).getSelectedItems(),
        that = this;

        this.oDataModel.setDeferredGroups(["deleteItems"]);
        for (let index = 0; index < selectedData.length; index++) {
            const element: any = selectedData[index].getBindingContext()?.getObject() || {};

            if (!element) continue;

            this.oDataModel.create("/falsedelete", {}, {
                urlParameters: {
                    "Companycode": `'${element.Companycode}'`,
                    "Documentdate":`datetime'${element.Documentdate.toISOString().replace("Z","")}'`,
                    "Bpartner": `'${element.Bpartner}'`

                },
                headers:{
                    "If-Match":"*"
                },
                success:function(){
                    (that.byId("_IDGenSmartTable") as SmartTable).rebindTable(true);
                }
            })

        }

    }


    public onClickPost() {
        let selectedData = (this.byId("RespTable") as Table).getSelectedItems(),
        that = this;

        this.oDataModel.setDeferredGroups(["deleteItems"]);
        for (let index = 0; index < selectedData.length; index++) {
            const element: any = selectedData[index].getBindingContext()?.getObject() || {};

            if (!element) continue;

            this.oDataModel.create("/post", {}, {
                urlParameters: {
                    "Companycode": `'${element.Companycode}'`,
                    "Documentdate":`datetime'${element.Documentdate.toISOString().replace("Z","")}'`,
                    "Bpartner": `'${element.Bpartner}'`

                },
                headers:{
                    "If-Match":"*"
                },
                success:function(){
                    (that.byId("_IDGenSmartTable") as SmartTable).rebindTable(true);
                }
            })

        }

    }

}