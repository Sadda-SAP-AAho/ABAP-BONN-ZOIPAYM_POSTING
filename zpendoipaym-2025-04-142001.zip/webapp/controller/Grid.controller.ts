import Controller from "sap/ui/core/mvc/Controller";
import ODataModel from "sap/ui/model/odata/v2/ODataModel";
import Table from "sap/m/Table";
import SmartTable from "sap/ui/comp/smarttable/SmartTable";
import MessageToast from "sap/m/MessageToast";

/**
 * @namespace zpendoipaym.controller
 */
export default class Grid extends Controller {

    public oDataModel: ODataModel;
    public selectedDoc: string;

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {
        this.oDataModel = new ODataModel("/sap/opu/odata/sap/ZUI_OIPAYMENTS_O2/", {
            defaultCountMode: "None"
        });
    }

    public onClickDelete() {
        let selectedData = (this.byId("RespTable") as Table).getSelectedItems(),
            that = this;

        this.oDataModel.setDeferredGroups(["deleteItems"]);
        for (let index = 0; index < selectedData.length; index++) {
            const element: any = selectedData[index].getBindingContext()?.getObject() || {};

            if (!element) continue;

            this.oDataModel.create("/falsedelete", {}, {
                urlParameters: {
                    "Companycode": `'${element.Companycode}'`,
                    "Documentdate": `datetime'${element.Documentdate.toISOString().replace("Z", "")}'`,
                    "Bpartner": `'${element.Bpartner}'`,
                    "Createdtime":  `time'PT${Math.floor(element.Createdtime.ms/3600000)}H${Math.floor(element.Createdtime.ms/60000)%60}M${Math.floor(element.Createdtime.ms/1000)%60}S'`

                },
                headers: {
                    "If-Match": "*"
                },
                success: function () {
                    (that.byId("_IDGenSmartTable") as SmartTable).rebindTable(true);
                }
            })

        }

    }


    public onClickPost() {
        let selectedData = (this.byId("RespTable") as Table).getSelectedItems(),
            that = this;

        let data = selectedData.map((item) => {
            const element: any = item.getBindingContext()?.getObject() || {};


            return {
                "Companycode": element.Companycode,
                "Documentdate": element.Documentdate.toISOString().replace("T00:00:00.000Z", "").replace(/-/g,""),
                "Bpartner": element.Bpartner,
                //   "Createdtime":  `PT${Math.floor(element.Createdtime.ms/3600000)}H${Math.floor(element.Createdtime.ms/60000)%60}M${Math.floor(element.Createdtime.ms/1000)%60}S`
                "Createdtime": `${Math.floor(element.Createdtime.ms/3600000)}${Math.floor(element.Createdtime.ms/60000)%60}${Math.floor(element.Createdtime.ms/1000)%60}`
            }
        })


        $.ajax({
            url: '/sap/bc/http/sap/ZHTTP_OIPAYMPOST',
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(data),
            success: function () {
                (that.byId("_IDGenSmartTable") as SmartTable).rebindTable(true);
            },
            error: function (error) {
                MessageToast.show("Upload failed: " + (error.responseText || "Unknown error"));
            }
        });

    }

}