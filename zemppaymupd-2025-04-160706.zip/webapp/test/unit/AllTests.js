sap.ui.define([
	"zemppaymupd/test/unit/controller/Upload.controller"
], function () {
	"use strict";
});
