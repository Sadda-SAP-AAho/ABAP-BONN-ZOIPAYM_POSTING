/* global QUnit */

sap.ui.require(["zemppaymupd/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
